/*
 *  Squeezelite - lightweight headless squeezebox emulator
 *
 *  (c) Adrian Smith 2012-2015, triode1@btinternet.com
 *      Ralph Irving 2015-2021, ralph_irving@hotmail.com
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

// macOS CoreAudio native output
// Ported from OSXOutputPlugin.cxx (MPD project, GPL-2+)
// Build without PORTAUDIO: omit -DPA / portaudio from CFLAGS/LDFLAGS and
// add output_macos.c to the source list with -framework CoreAudio
// -framework AudioUnit -framework AudioToolbox.

#include "squeezelite.h"

#if OSX

#include <CoreAudio/CoreAudio.h>
#include <AudioUnit/AudioUnit.h>
#include <AudioToolbox/AudioToolbox.h>
#include <math.h>

// Backward compatibility: macOS 12.0 renamed the "master" element to "main"
#if (__MAC_OS_X_VERSION_MAX_ALLOWED >= 120000)
#  define CA_ELEMENT_MM kAudioObjectPropertyElementMain
#  define CA_VIRTUAL_VOLUME kAudioHardwareServiceDeviceProperty_VirtualMainVolume
#else
#  define CA_ELEMENT_MM kAudioObjectPropertyElementMaster
#  define CA_VIRTUAL_VOLUME kAudioHardwareServiceDeviceProperty_VirtualMasterVolume
#endif

#define MACOS_BUFFER_TIME_MS 100
// Maximum frames written to the ring buffer per output-thread iteration
#define CA_MAX_FRAMES 4096

// ---------------------------------------------------------------------------
// Simple lock-free ring buffer (single producer / single consumer)
// ---------------------------------------------------------------------------

struct ringbuf {
	u8_t   *buf;
	size_t  size;          // always a power-of-two + 1 (wrap sentinel not needed here)
	volatile size_t readp;
	volatile size_t writep;
};

static struct ringbuf *ringbuf_create(size_t size) {
	struct ringbuf *r = malloc(sizeof(*r));
	if (!r) return NULL;
	r->buf = malloc(size);
	if (!r->buf) { free(r); return NULL; }
	r->size   = size;
	r->readp  = 0;
	r->writep = 0;
	return r;
}

static void ringbuf_free(struct ringbuf *r) {
	if (r) { free(r->buf); free(r); }
}

static size_t ringbuf_read_avail(const struct ringbuf *r) {
	size_t w = r->writep, rd = r->readp;
	return (w >= rd) ? (w - rd) : (r->size - rd + w);
}

static size_t ringbuf_write_avail(const struct ringbuf *r) {
	// keep one byte gap so full != empty
	return r->size - 1 - ringbuf_read_avail(r);
}

static size_t ringbuf_read(struct ringbuf *r, u8_t *dst, size_t count) {
	size_t avail = ringbuf_read_avail(r);
	if (count > avail) count = avail;
	size_t rd = r->readp;
	size_t first = r->size - rd;
	if (first >= count) {
		memcpy(dst, r->buf + rd, count);
	} else {
		memcpy(dst,         r->buf + rd, first);
		memcpy(dst + first, r->buf,      count - first);
	}
	__sync_synchronize();
	r->readp = (rd + count) % r->size;
	return count;
}

static size_t ringbuf_write(struct ringbuf *r, const u8_t *src, size_t count) {
	size_t avail = ringbuf_write_avail(r);
	if (count > avail) count = avail;
	size_t wr = r->writep;
	size_t first = r->size - wr;
	if (first >= count) {
		memcpy(r->buf + wr, src,         count);
	} else {
		memcpy(r->buf + wr, src,         first);
		memcpy(r->buf,      src + first, count - first);
	}
	__sync_synchronize();
	r->writep = (wr + count) % r->size;
	return count;
}

static void ringbuf_reset(struct ringbuf *r) {
	r->readp = r->writep = 0;
}

// ---------------------------------------------------------------------------
// Module state
// ---------------------------------------------------------------------------

static struct {
	AudioComponentInstance    au;
	AudioStreamBasicDescription asbd;
	AudioDeviceID             dev_id;
	struct ringbuf           *ring;
	bool                      started;
	bool                      hog_device;
	const char               *device_name;
	OSType                    component_subtype;
} ca;

static log_level  loglevel;
static bool       running = true;
static thread_type output_thread_t;
static u8_t        ca_writebuf[CA_MAX_FRAMES * BYTES_PER_FRAME];

extern struct outputstate output;
extern struct buffer     *outputbuf;
extern u8_t              *silencebuf;
#if DSD
extern u8_t              *silencebuf_dsd;
#endif

#define LOCK   mutex_lock(outputbuf->mutex)
#define UNLOCK mutex_unlock(outputbuf->mutex)

// ---------------------------------------------------------------------------
// Device enumeration helpers
// ---------------------------------------------------------------------------

// Fill *out_id with the AudioDeviceID whose name matches 'name'.
// Returns true on success.
static bool ca_find_device_by_name(const char *name, AudioDeviceID *out_id) {
	static const AudioObjectPropertyAddress aopa_devices = {
		kAudioHardwarePropertyDevices,
		kAudioObjectPropertyScopeGlobal,
		CA_ELEMENT_MM,
	};
	static const AudioObjectPropertyAddress aopa_name = {
		kAudioObjectPropertyName,
		kAudioObjectPropertyScopeGlobal,
		CA_ELEMENT_MM,
	};

	UInt32 size = 0;
	if (AudioObjectGetPropertyDataSize(kAudioObjectSystemObject, &aopa_devices,
	                                   0, NULL, &size) != noErr)
		return false;

	AudioDeviceID *ids = malloc(size);
	if (!ids) return false;

	if (AudioObjectGetPropertyData(kAudioObjectSystemObject, &aopa_devices,
	                               0, NULL, &size, ids) != noErr) {
		free(ids);
		return false;
	}

	UInt32 count = size / sizeof(AudioDeviceID);
	bool found = false;

	for (UInt32 i = 0; i < count && !found; i++) {
		CFStringRef cfname = NULL;
		UInt32 ns = sizeof(cfname);
		if (AudioObjectGetPropertyData(ids[i], &aopa_name,
		                               0, NULL, &ns, &cfname) != noErr)
			continue;
		char buf[256];
		if (CFStringGetCString(cfname, buf, sizeof(buf), kCFStringEncodingUTF8)
		    && strcmp(buf, name) == 0) {
			*out_id = ids[i];
			found = true;
		}
		CFRelease(cfname);
	}

	free(ids);
	return found;
}

// ---------------------------------------------------------------------------
// Public API: list devices, set volume, test open
// (guard with !PORTAUDIO to avoid clashing with output_pa.c when both are
//  compiled; define COREAUDIO in the Makefile instead of PORTAUDIO to use
//  this file exclusively on macOS)
// ---------------------------------------------------------------------------

#if !PORTAUDIO

void list_devices(void) {
	static const AudioObjectPropertyAddress aopa_devices = {
		kAudioHardwarePropertyDevices,
		kAudioObjectPropertyScopeGlobal,
		CA_ELEMENT_MM,
	};
	static const AudioObjectPropertyAddress aopa_name = {
		kAudioObjectPropertyName,
		kAudioObjectPropertyScopeGlobal,
		CA_ELEMENT_MM,
	};

	UInt32 size = 0;
	if (AudioObjectGetPropertyDataSize(kAudioObjectSystemObject, &aopa_devices,
	                                   0, NULL, &size) != noErr) {
		LOG_WARN("cannot enumerate audio devices");
		return;
	}

	AudioDeviceID *ids = malloc(size);
	if (!ids) return;

	if (AudioObjectGetPropertyData(kAudioObjectSystemObject, &aopa_devices,
	                               0, NULL, &size, ids) != noErr) {
		free(ids);
		return;
	}

	UInt32 count = size / sizeof(AudioDeviceID);
	printf("Output devices:\n");

	for (UInt32 i = 0; i < count; i++) {
		CFStringRef cfname = NULL;
		UInt32 ns = sizeof(cfname);
		if (AudioObjectGetPropertyData(ids[i], &aopa_name,
		                               0, NULL, &ns, &cfname) != noErr)
			continue;
		char buf[256];
		if (CFStringGetCString(cfname, buf, sizeof(buf), kCFStringEncodingUTF8))
			printf("  %s\n", buf);
		CFRelease(cfname);
	}

	printf("\n");
	free(ids);
}

void set_volume(unsigned left, unsigned right) {
	LOG_DEBUG("setting internal gain left: %u right: %u", left, right);
	LOCK;
	output.gainL = left;
	output.gainR = right;
	UNLOCK;
}

// Populate rates[] with all reference sample rates (CoreAudio handles
// resampling internally; we accept them all and let ca_set_device_format
// pick the best physical format at open time).
bool test_open(const char *device, unsigned rates[], bool userdef_rates) {
	unsigned ref[] TEST_RATES;
	if (!userdef_rates) {
		int i, ind = 0;
		for (i = 0; ref[i]; i++)
			rates[ind++] = ref[i];
	}
	return true;
}

#endif // !PORTAUDIO

// ---------------------------------------------------------------------------
// Volume via AudioHardwareService
// ---------------------------------------------------------------------------

int ca_get_volume(void) {
	static const AudioObjectPropertyAddress aopa = {
		CA_VIRTUAL_VOLUME,
		kAudioObjectPropertyScopeOutput,
		CA_ELEMENT_MM,
	};
	Float32 vol = 0.0f;
	UInt32 size = sizeof(vol);
	AudioObjectGetPropertyData(ca.dev_id, &aopa, 0, NULL, &size, &vol);
	return (int)(vol * 100.0f);
}

void ca_set_volume(unsigned new_volume) {
	static const AudioObjectPropertyAddress aopa = {
		CA_VIRTUAL_VOLUME,
		kAudioObjectPropertyScopeOutput,
		CA_ELEMENT_MM,
	};
	Float32 vol = new_volume / 100.0f;
	UInt32 size = sizeof(vol);
	OSStatus err = AudioObjectSetPropertyData(ca.dev_id, &aopa, 0, NULL, size, &vol);
	if (err != noErr)
		LOG_WARN("ca_set_volume failed: %d", (int)err);
}

// ---------------------------------------------------------------------------
// Exclusive (hog) mode
// ---------------------------------------------------------------------------

static void ca_hog_device(AudioDeviceID dev_id, bool hog) {
	static const AudioObjectPropertyAddress aopa = {
		kAudioDevicePropertyHogMode,
		kAudioObjectPropertyScopeOutput,
		CA_ELEMENT_MM,
	};

	pid_t hog_pid = -1;
	UInt32 size = sizeof(hog_pid);
	if (AudioObjectGetPropertyData(dev_id, &aopa, 0, NULL, &size, &hog_pid) != noErr) {
		LOG_DEBUG("failed to query HogMode");
		return;
	}

	if (hog) {
		if (hog_pid != -1) { LOG_DEBUG("device already hogged"); return; }
		hog_pid = getpid();
	} else {
		if (hog_pid != getpid()) { LOG_DEBUG("device not owned by us"); return; }
		hog_pid = -1;
	}

	size = sizeof(hog_pid);
	OSStatus err = AudioObjectSetPropertyData(dev_id, &aopa, 0, NULL, size, &hog_pid);
	if (err != noErr) {
		LOG_WARN("hog device failed: %d", (int)err);
	} else {
		if (hog_pid == -1) {
			LOG_DEBUG("device unhogged");
		} else {
			LOG_DEBUG("device hogged");
		}
	}
}

// ---------------------------------------------------------------------------
// Format scoring (ported 1:1 from OSXOutputPlugin.cxx)
// ---------------------------------------------------------------------------

static float ca_score_sample_rate(Float64 dest_rate, unsigned src_rate) {
	float score = 0;
	double int_part;
	double frac = modf(src_rate / dest_rate, &int_part);

	if (frac < 0.01 || frac >= 0.99) score += 1000;
	score += (int_part == 1.0) ? 500 : 0;
	if ((unsigned)dest_rate == src_rate)
		score += 1000;
	else if (src_rate > (unsigned)dest_rate)
		score += (int_part > 1 && int_part < 100) ? (float)((100 - int_part) / 100.0 * 100.0) : 0;
	else
		score += (int_part > 1 && int_part < 100) ? (float)((100 + int_part) / 100.0 * 100.0) : 0;

	return score;
}

static float ca_score_format(const AudioStreamBasicDescription *fmt,
                              const AudioStreamBasicDescription *target) {
	if (fmt->mFormatID != kAudioFormatLinearPCM) return 0;

	float score = ca_score_sample_rate(fmt->mSampleRate, (unsigned)target->mSampleRate);
	score += fmt->mChannelsPerFrame * 5;

	if (target->mFormatFlags & kLinearPCMFormatFlagIsFloat) {
		if (fmt->mBitsPerChannel >= 16)
			score += fmt->mBitsPerChannel / 8;
	} else {
		if (fmt->mBitsPerChannel == target->mBitsPerChannel)
			score += 5;
		else if (fmt->mBitsPerChannel > target->mBitsPerChannel)
			score += 1;
	}
	return score;
}

// Walk the device's output streams, score each physical format against
// *target, set the best one, and return its sample rate.
static Float64 ca_set_device_format(AudioDeviceID dev_id,
                                     const AudioStreamBasicDescription *target) {
	static const AudioObjectPropertyAddress aopa_streams = {
		kAudioDevicePropertyStreams,
		kAudioObjectPropertyScopeOutput,
		CA_ELEMENT_MM,
	};
	static const AudioObjectPropertyAddress aopa_direction = {
		kAudioStreamPropertyDirection,
		kAudioObjectPropertyScopeOutput,
		CA_ELEMENT_MM,
	};
	static const AudioObjectPropertyAddress aopa_phys_formats = {
		kAudioStreamPropertyAvailablePhysicalFormats,
		kAudioObjectPropertyScopeOutput,
		CA_ELEMENT_MM,
	};
	static const AudioObjectPropertyAddress aopa_phys_format = {
		kAudioStreamPropertyPhysicalFormat,
		kAudioObjectPropertyScopeOutput,
		CA_ELEMENT_MM,
	};

	UInt32 size = 0;
	if (AudioObjectGetPropertyDataSize(dev_id, &aopa_streams, 0, NULL, &size) != noErr)
		return target->mSampleRate;

	AudioStreamID *streams = malloc(size);
	if (!streams) return target->mSampleRate;

	AudioObjectGetPropertyData(dev_id, &aopa_streams, 0, NULL, &size, streams);
	UInt32 num_streams = size / sizeof(AudioStreamID);

	bool format_found = false;
	AudioStreamBasicDescription best_fmt;
	AudioStreamID best_stream = 0;
	float best_score = 0;

	for (UInt32 si = 0; si < num_streams; si++) {
		UInt32 direction = 0, dir_size = sizeof(direction);
		AudioObjectGetPropertyData(streams[si], &aopa_direction,
		                           0, NULL, &dir_size, &direction);
		if (direction != 0) continue; // 0 = output

		UInt32 fmts_size = 0;
		if (AudioObjectGetPropertyDataSize(streams[si], &aopa_phys_formats,
		                                   0, NULL, &fmts_size) != noErr)
			continue;

		AudioStreamRangedDescription *fmts = malloc(fmts_size);
		if (!fmts) continue;

		AudioObjectGetPropertyData(streams[si], &aopa_phys_formats,
		                           0, NULL, &fmts_size, fmts);
		UInt32 num_fmts = fmts_size / sizeof(AudioStreamRangedDescription);

		for (UInt32 fi = 0; fi < num_fmts; fi++) {
			AudioStreamBasicDescription fd = fmts[fi].mFormat;
			if (fd.mSampleRate == kAudioStreamAnyRate)
				fd.mSampleRate = target->mSampleRate;
			float score = ca_score_format(&fd, target);
			if (score > best_score) {
				best_score  = score;
				best_fmt    = fd;
				best_stream = streams[si];
				format_found = true;
			}
		}
		free(fmts);
	}

	free(streams);

	if (format_found) {
		OSStatus err = AudioObjectSetPropertyData(best_stream, &aopa_phys_format,
		                                          0, NULL, sizeof(best_fmt), &best_fmt);
		if (err != noErr) {
			LOG_WARN("failed to set device format: %d", (int)err);
		} else {
			LOG_INFO("device format set: %.0f Hz %u ch %u-bit",
			         best_fmt.mSampleRate,
			         (unsigned)best_fmt.mChannelsPerFrame,
			         (unsigned)best_fmt.mBitsPerChannel);
		}
		return best_fmt.mSampleRate;
	}

	return target->mSampleRate;
}

// ---------------------------------------------------------------------------
// Buffer size: try to use the device maximum; round up to a power of two.
// ---------------------------------------------------------------------------

static UInt32 ca_set_buffer_size(AudioComponentInstance au,
                                  const AudioStreamBasicDescription *desc) {
	AudioValueRange value_range = {0, 0};
	UInt32 size = sizeof(value_range);
	AudioUnitGetProperty(au, kAudioDevicePropertyBufferFrameSizeRange,
	                     kAudioUnitScope_Global, 0, &value_range, &size);

	UInt32 max_frames = (UInt32)value_range.mMaximum;
	if (max_frames > 0)
		AudioUnitSetProperty(au, kAudioDevicePropertyBufferFrameSize,
		                     kAudioUnitScope_Global, 0, &max_frames, sizeof(max_frames));

	UInt32 buf_frame_size = 0;
	size = sizeof(buf_frame_size);
	AudioUnitGetProperty(au, kAudioDevicePropertyBufferFrameSize,
	                     kAudioUnitScope_Global, 0, &buf_frame_size, &size);
	buf_frame_size *= desc->mBytesPerFrame;

	UInt32 frame_size = 1;
	while (frame_size < buf_frame_size + 1)
		frame_size <<= 1;

	return frame_size;
}

// ---------------------------------------------------------------------------
// CoreAudio render callback (real-time thread — no locks, no allocs)
// ---------------------------------------------------------------------------

static OSStatus ca_render(void *inRefCon,
                           AudioUnitRenderActionFlags *ioActionFlags,
                           const AudioTimeStamp *inTimeStamp,
                           UInt32 inBusNumber,
                           UInt32 inNumberFrames,
                           AudioBufferList *ioData) {
	(void)inRefCon; (void)ioActionFlags; (void)inTimeStamp; (void)inBusNumber;

	size_t count = inNumberFrames * ca.asbd.mBytesPerFrame;
	size_t got   = ringbuf_read(ca.ring,
	                            (u8_t *)ioData->mBuffers[0].mData,
	                            count);

	// Always report the full buffer size; pad any underrun with silence
	if (got < count)
		memset((u8_t *)ioData->mBuffers[0].mData + got, 0, count - got);
	ioData->mBuffers[0].mDataByteSize = (UInt32)count;

	return noErr;
}

// ---------------------------------------------------------------------------
// _write_frames: called by _output_frames() with mutex held
// Writes into ca_writebuf (global, guarded by outputbuf mutex)
// ---------------------------------------------------------------------------

static u8_t *optr;

static int _write_frames(frames_t out_frames, bool silence, s32_t gainL, s32_t gainR,
                          s32_t cross_gain_in, s32_t cross_gain_out, s32_t **cross_ptr) {

	if (!silence) {
		if (output.fade == FADE_ACTIVE && output.fade_dir == FADE_CROSS && *cross_ptr)
			_apply_cross(outputbuf, out_frames, cross_gain_in, cross_gain_out, cross_ptr);

		if (gainL != FIXED_ONE || gainR != FIXED_ONE)
			_apply_gain(outputbuf, out_frames, gainL, gainR);

		IF_DSD(
			if (output.outfmt == DOP)
				update_dop((u32_t *)outputbuf->readp, out_frames, output.invert);
			else if (output.outfmt != PCM && output.invert)
				dsd_invert((u32_t *)outputbuf->readp, out_frames);
		)

		memcpy(optr, outputbuf->readp, out_frames * BYTES_PER_FRAME);
	} else {
		u8_t *buf = silencebuf;
		IF_DSD(
			if (output.outfmt != PCM) {
				buf = silencebuf_dsd;
				update_dop((u32_t *)buf, out_frames, false);
			}
		)
		memcpy(optr, buf, out_frames * BYTES_PER_FRAME);
	}

	optr += out_frames * BYTES_PER_FRAME;
	return (int)out_frames;
}

// ---------------------------------------------------------------------------
// Output thread: produces into ring buffer; CoreAudio render thread consumes
// ---------------------------------------------------------------------------

static void *ca_output_thread(void *arg) {
	(void)arg;

	while (running) {
		LOCK;

		if (output.state == OUTPUT_OFF) {
			UNLOCK;
			usleep(200000);
			continue;
		}

		// Detect sample rate change (e.g. switching from 44100 to 96000 Hz track)
		if (output.current_sample_rate != (unsigned)ca.asbd.mSampleRate) {
			LOG_INFO("sample rate change: %u -> %u Hz",
			         (unsigned)ca.asbd.mSampleRate, output.current_sample_rate);
			if (ca.started) {
				AudioOutputUnitStop(ca.au);
				ca.started = false;
			}
			AudioUnitUninitialize(ca.au);
			ringbuf_reset(ca.ring);

			ca.asbd.mSampleRate = output.current_sample_rate;
			ca_set_device_format(ca.dev_id, &ca.asbd);
			AudioUnitSetProperty(ca.au, kAudioUnitProperty_StreamFormat,
			                     kAudioUnitScope_Input, 0,
			                     &ca.asbd, sizeof(ca.asbd));
			OSStatus st = AudioUnitInitialize(ca.au);
			if (st != noErr)
				LOG_WARN("AudioUnitInitialize (rate change) failed: %d", (int)st);
			UNLOCK;
			continue;
		}

		// How many frames can we write without overflow?
		size_t avail_bytes = ringbuf_write_avail(ca.ring);
		frames_t max_frames = (frames_t)(avail_bytes / ca.asbd.mBytesPerFrame);
		if (max_frames > CA_MAX_FRAMES) max_frames = CA_MAX_FRAMES;

		if (max_frames == 0) {
			UNLOCK;
			usleep(1000);
			continue;
		}

		optr = ca_writebuf;

		output.device_frames     = 0;
		output.updated           = gettime_ms();
		output.frames_played_dmp = output.frames_played;

		frames_t wrote = _output_frames(max_frames);

		if (wrote > 0)
			ringbuf_write(ca.ring, ca_writebuf, wrote * ca.asbd.mBytesPerFrame);

		// Start the AudioUnit once we have some data buffered
		if (!ca.started && ringbuf_read_avail(ca.ring) >= ca.asbd.mBytesPerFrame) {
			OSStatus status = AudioOutputUnitStart(ca.au);
			if (status != noErr) {
				LOG_WARN("AudioOutputUnitStart failed: %d", (int)status);
			} else {
				ca.started = true;
				LOG_INFO("audio output started");
			}
		}

		UNLOCK;
	}

	return NULL;
}

// ---------------------------------------------------------------------------
// output_init_macos / output_close_macos
// ---------------------------------------------------------------------------

void output_init_macos(log_level level, const char *device, unsigned output_buf_size,
                        char *params, unsigned rates[], unsigned rate_delay, unsigned idle) {
	loglevel = level;
	LOG_INFO("init output");

	memset(&output, 0, sizeof(output));
	memset(&ca,     0, sizeof(ca));

	output.format       = 0;
	output.start_frames = 0;
	output.write_cb     = &_write_frames;
	output.rate_delay   = rate_delay;

	// params: optional "hog" flag to request exclusive device access
	ca.hog_device = params && strstr(params, "hog");

	// Determine component subtype from device string
	if (!device || strcmp(device, "default") == 0) {
		ca.component_subtype = kAudioUnitSubType_DefaultOutput;
		ca.device_name       = NULL;
	} else if (strcmp(device, "system") == 0) {
		ca.component_subtype = kAudioUnitSubType_SystemOutput;
		ca.device_name       = NULL;
	} else {
		ca.component_subtype = kAudioUnitSubType_HALOutput;
		ca.device_name       = device;
	}

	// Retrieve the initial default/system device ID
	AudioObjectPropertyAddress aopa_default = {
		(ca.component_subtype == kAudioUnitSubType_SystemOutput)
			? kAudioHardwarePropertyDefaultSystemOutputDevice
			: kAudioHardwarePropertyDefaultOutputDevice,
		kAudioObjectPropertyScopeOutput,
		CA_ELEMENT_MM,
	};
	AudioDeviceID dev_id  = kAudioDeviceUnknown;
	UInt32        id_size = sizeof(dev_id);
	AudioObjectGetPropertyData(kAudioObjectSystemObject, &aopa_default,
	                           0, NULL, &id_size, &dev_id);
	ca.dev_id = dev_id;

	// Find and instantiate the AudioUnit component
	AudioComponentDescription comp_desc = {
		.componentType         = kAudioUnitType_Output,
		.componentSubType      = ca.component_subtype,
		.componentManufacturer = kAudioUnitManufacturer_Apple,
		.componentFlags        = 0,
		.componentFlagsMask    = 0,
	};
	AudioComponent comp = AudioComponentFindNext(NULL, &comp_desc);
	if (!comp) {
		LOG_ERROR("CoreAudio output component not found");
		return;
	}

	OSStatus status = AudioComponentInstanceNew(comp, &ca.au);
	if (status != noErr) {
		LOG_ERROR("AudioComponentInstanceNew failed: %d", (int)status);
		return;
	}

	// For HALOutput: explicitly enable output I/O and disable input I/O.
	// DefaultOutput/SystemOutput have I/O enabled by default; HALOutput does not.
	if (ca.component_subtype == kAudioUnitSubType_HALOutput) {
		UInt32 enable = 1;
		AudioUnitSetProperty(ca.au, kAudioOutputUnitProperty_EnableIO,
		                     kAudioUnitScope_Output, 0, &enable, sizeof(enable));
		UInt32 disable = 0;
		AudioUnitSetProperty(ca.au, kAudioOutputUnitProperty_EnableIO,
		                     kAudioUnitScope_Input, 1, &disable, sizeof(disable));
	}

	// Override device if a name was given
	if (ca.component_subtype == kAudioUnitSubType_HALOutput && ca.device_name) {
		AudioDeviceID named_id;
		if (ca_find_device_by_name(ca.device_name, &named_id)) {
			AudioUnitSetProperty(ca.au, kAudioOutputUnitProperty_CurrentDevice,
			                     kAudioUnitScope_Global, 0,
			                     &named_id, sizeof(named_id));
			ca.dev_id = named_id;
			LOG_INFO("using device: %s (id=%u)", ca.device_name, (unsigned)named_id);
		} else {
			LOG_WARN("device '%s' not found, using default", ca.device_name);
		}
	}

	if (ca.hog_device)
		ca_hog_device(ca.dev_id, true);

	output_init_common(level, device, output_buf_size, rates, idle);

	// Build the AudioStreamBasicDescription we want the AudioUnit to accept.
	// We use signed 32-bit native-endian PCM (matches squeezelite's internal
	// BYTES_PER_FRAME == 8 / 2-ch / 32-bit format).
	memset(&ca.asbd, 0, sizeof(ca.asbd));
	ca.asbd.mFormatID         = kAudioFormatLinearPCM;
	ca.asbd.mFormatFlags      = kLinearPCMFormatFlagIsSignedInteger
	                          | kAudioFormatFlagsNativeEndian
	                          | kLinearPCMFormatFlagIsPacked;
	ca.asbd.mBitsPerChannel   = 32;
	ca.asbd.mChannelsPerFrame = 2;
	ca.asbd.mFramesPerPacket  = 1;
	ca.asbd.mBytesPerFrame    = ca.asbd.mChannelsPerFrame * (ca.asbd.mBitsPerChannel / 8);
	ca.asbd.mBytesPerPacket   = ca.asbd.mBytesPerFrame;
	ca.asbd.mSampleRate       = output.current_sample_rate;

	// Try to configure the device's physical format for bit-perfect output
	ca_set_device_format(ca.dev_id, &ca.asbd);

	// Tell the AudioUnit what format it will receive from us
	status = AudioUnitSetProperty(ca.au, kAudioUnitProperty_StreamFormat,
	                              kAudioUnitScope_Input, 0,
	                              &ca.asbd, sizeof(ca.asbd));
	if (status != noErr)
		LOG_WARN("StreamFormat set failed: %d", (int)status);

	// Register the render callback
	AURenderCallbackStruct cb = { .inputProc = ca_render, .inputProcRefCon = NULL };
	status = AudioUnitSetProperty(ca.au, kAudioUnitProperty_SetRenderCallback,
	                              kAudioUnitScope_Input, 0, &cb, sizeof(cb));
	if (status != noErr)
		LOG_WARN("SetRenderCallback failed: %d", (int)status);

	status = AudioUnitInitialize(ca.au);
	if (status != noErr) {
		LOG_ERROR("AudioUnitInitialize failed: %d", (int)status);
		AudioComponentInstanceDispose(ca.au);
		return;
	}

	// Ring buffer: at least MACOS_BUFFER_TIME_MS worth of audio, rounded up
	// to the next power-of-two for efficient wrapping, plus a 1-byte sentinel.
	UInt32 buf_frames = ca_set_buffer_size(ca.au, &ca.asbd);
	size_t time_bytes = (size_t)(MACOS_BUFFER_TIME_MS
	                             * ca.asbd.mSampleRate / 1000
	                             * ca.asbd.mBytesPerFrame);
	size_t ring_size  = buf_frames > time_bytes ? buf_frames : time_bytes;
	// round up to power of two
	size_t pow2 = 1;
	while (pow2 < ring_size) pow2 <<= 1;
	ca.ring = ringbuf_create(pow2 + 1);
	if (!ca.ring) {
		LOG_ERROR("ring buffer allocation failed");
		AudioUnitUninitialize(ca.au);
		AudioComponentInstanceDispose(ca.au);
		return;
	}

	ca.started = false;
	running    = true;

	pthread_create(&output_thread_t, NULL, ca_output_thread, NULL);
}

void output_close_macos(void) {
	LOG_INFO("close output");

	LOCK;
	running = false;
	UNLOCK;

	pthread_join(output_thread_t, NULL);

	if (ca.started) {
		AudioOutputUnitStop(ca.au);
		ringbuf_reset(ca.ring);
		ca.started = false;
	}

	AudioUnitUninitialize(ca.au);
	AudioComponentInstanceDispose(ca.au);

	if (ca.hog_device)
		ca_hog_device(ca.dev_id, false);

	ringbuf_free(ca.ring);
	ca.ring = NULL;

	output_close_common();
}

#endif // OSX
